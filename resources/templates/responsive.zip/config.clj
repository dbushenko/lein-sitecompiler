{:tags-pages [{:tag "index"
               :list-template "index"
               :page-template "article"
               }]
 :single-pages [{:file-name "contact"
                 :template "page"}]}
